﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
public partial class _login : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CONN"].ToString());


    protected void Button1_Click(object sender, EventArgs e)
    {
        string uid = tx1.Text;
        string pass = tx2.Text;

        con.Open();
        string qry = "select * from DEX where username='" + uid + "' and password='" + pass + "'";
        SqlCommand cmd = new SqlCommand(qry, con);
        SqlDataReader sdr = cmd.ExecuteReader();
        //SqlCommand  red = select * from DEX ;
        if (sdr.Read())
        {
            //lblerr.Text = "Login Sucess......!!";
            Response.Redirect("main.aspx");
           // lblerr.Text = red;
        }
        else
        {
            lblerr.Text = "UserId & Password Is not correct Try again..!!";

        }
        con.Close();
    }




}
