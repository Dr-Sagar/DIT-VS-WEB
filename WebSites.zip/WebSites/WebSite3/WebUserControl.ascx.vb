﻿
Partial Class WebUserControl
    Inherits System.Web.UI.UserControl

End Class
