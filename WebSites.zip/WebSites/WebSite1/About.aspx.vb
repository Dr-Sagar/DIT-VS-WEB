﻿
Partial Class About
    Inherits System.Web.UI.Page

End Class
